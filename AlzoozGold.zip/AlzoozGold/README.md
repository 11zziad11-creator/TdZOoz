# AlzoozGold
موقع لتحليلات الذهب والبيتكوين، تحديث مباشر، أخبار، تحليلات يومية وأسعار لحظية.

## كيفية التشغيل على GitHub Pages
1. أنشئ Repository Public على GitHub.
2. ارفع جميع الملفات (`index.html`, `daily_analysis.json`, `assets/`).
3. اذهب إلى Settings > Pages > Branch: main > /root.
4. اضغط Save.
5. الموقع سيكون مباشرًا عبر الرابط الذي يظهر لك.
6. ضع مفاتيح API الخاصة بك في `index.html`.
